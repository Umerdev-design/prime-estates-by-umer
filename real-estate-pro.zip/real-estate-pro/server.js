const express = require('express');
const path = require('path');
const helmet = require('helmet');

const app = express();
const PORT = process.env.PORT || 3000;

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(express.json({ limit: '10kb' }));
app.use(express.static(__dirname, { maxAge: '1d' }));

const sanitize = (value) => String(value || '').trim().replace(/[<>]/g, '');

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/contact', (req, res) => {
    const { name, email, phone, message } = req.body || {};
    const cleaned = {
        name: sanitize(name),
        email: sanitize(email).toLowerCase(),
        phone: sanitize(phone),
        message: sanitize(message)
    };

    const errors = [];

    if (!cleaned.name || cleaned.name.length < 2) {
        errors.push('Please enter your full name.');
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleaned.email)) {
        errors.push('Please provide a valid email address.');
    }

    if (!/^[0-9+()\-\s]{7,15}$/.test(cleaned.phone)) {
        errors.push('Please provide a valid phone number.');
    }

    if (!cleaned.message || cleaned.message.length < 10) {
        errors.push('Please share a message with at least 10 characters.');
    }

    if (errors.length) {
        return res.status(400).json({ success: false, message: errors[0] });
    }

    console.log('New contact form submission:', cleaned);
    return res.status(200).json({
        success: true,
        message: 'Thank you! Your message was received. We will contact you shortly.'
    });
});

app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, '404.html'));
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});